<?php
require_once '../db_config.php';
require_once '../cors.php';

header("Content-Type: application/json");

$input = json_decode(file_get_contents("php://input"), true);

if (!isset($input['id'])) {
    echo json_encode(["error" => "Falta el ID de la mascota"]);
    exit;
}

$id = $input['id'];

try {
    $stmt = $conn->prepare("DELETE FROM mascotas WHERE id = ?");
    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(["mensaje" => "Mascota eliminada correctamente"]);
    } else {
        echo json_encode(["error" => "No se encontró la mascota con ese ID"]);
    }
} catch (PDOException $e) {
    echo json_encode(["error" => "Error al eliminar: " . $e->getMessage()]);
}
?>
