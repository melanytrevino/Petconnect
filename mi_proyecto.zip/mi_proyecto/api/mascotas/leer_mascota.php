<?php
require_once "../../cors.php";
require_once "../../db_config.php";

header("Content-Type: application/json");

try {
    $stmt = $conexion->prepare("SELECT * FROM mascotas");
    $stmt->execute();
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($resultados);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
