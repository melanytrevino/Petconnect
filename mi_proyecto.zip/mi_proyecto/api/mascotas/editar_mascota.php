<?php
require_once "../../cors.php";
require_once "../../db_config.php";

header("Content-Type: application/json");

$datos = json_decode(file_get_contents("php://input"), true);

if (
    !isset($datos['id']) ||
    !isset($datos['nombre']) ||
    !isset($datos['tipo']) ||
    !isset($datos['edad']) ||
    !isset($datos['raza']) ||
    !isset($datos['descripcion']) ||
    !isset($datos['estado'])
) {
    echo json_encode(["error" => "Faltan datos"]);
    exit;
}

$id = $datos['id'];
$nombre = $datos['nombre'];
$tipo = $datos['tipo'];
$edad = $datos['edad'];
$raza = $datos['raza'];
$descripcion = $datos['descripcion'];
$estado = $datos['estado'];

try {
    $stmt = $conexion->prepare("UPDATE mascotas SET nombre=?, tipo=?, edad=?, raza=?, descripcion=?, estado=? WHERE id=?");
    $stmt->execute([$nombre, $tipo, $edad, $raza, $descripcion, $estado, $id]);

    echo json_encode(["mensaje" => "Mascota actualizada"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
