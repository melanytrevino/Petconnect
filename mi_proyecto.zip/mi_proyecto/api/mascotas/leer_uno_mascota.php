<?php
require_once "../../cors.php";
require_once "../../db_config.php";

header("Content-Type: application/json");

// Obtener el ID desde GET o JSON
$id = null;
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    $datos = json_decode(file_get_contents("php://input"), true);
    $id = $datos['id'] ?? null;
}

if (!$id) {
    echo json_encode(["error" => "Falta el ID"]);
    exit;
}

try {
    $stmt = $conexion->prepare("SELECT * FROM mascotas WHERE id = ?");
    $stmt->execute([$id]);
    $mascota = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($mascota) {
        echo json_encode($mascota);
    } else {
        echo json_encode(["mensaje" => "Mascota no encontrada"]);
    }
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
