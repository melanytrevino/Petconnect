<?php
require_once "../../cors.php";
require_once "../../db_config.php";

header("Content-Type: application/json");

$datos = json_decode(file_get_contents("php://input"), true);

if (
    !isset($datos['nombre']) ||
    !isset($datos['tipo']) ||
    !isset($datos['edad']) ||
    !isset($datos['raza']) ||
    !isset($datos['descripcion']) ||
    !isset($datos['estado'])
) {
    echo json_encode(["error" => "Faltan datos"]);
    exit;
}

$nombre = $datos['nombre'];
$tipo = $datos['tipo'];
$edad = $datos['edad'];
$raza = $datos['raza'];
$descripcion = $datos['descripcion'];
$estado = $datos['estado'];

try {
    $stmt = $conexion->prepare("INSERT INTO mascotas (nombre, tipo, edad, raza, descripcion, estado) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$nombre, $tipo, $edad, $raza, $descripcion, $estado]);

    echo json_encode(["mensaje" => "Mascota creada"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>

