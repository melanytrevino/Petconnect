<?php
// obtener.php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Subir dos carpetas hasta donde está db_config.php
require_once '../../db_config.php';

try {
    // Cambia 'contactos' por 'mascotas'
    $stmt = $conexion->prepare("SELECT * FROM mascotas");
    $stmt->execute();
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($resultados);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
