<?php
require_once('../db_config.php');

try {
    $stmt = $conexion->query("SHOW TABLES");
    $tablas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "Conexión exitosa. Tablas encontradas:<br>";
    foreach ($tablas as $tabla) {
        echo implode(", ", $tabla) . "<br>";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
