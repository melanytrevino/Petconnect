import { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [mascotas, setMascotas] = useState([]);
  const [nuevaMascota, setNuevaMascota] = useState({
    nombre: "",
    tipo: "",
    edad: "",
    raza: "",
    descripcion: "",
    estado: "",
  });

  const [editando, setEditando] = useState(null);

  useEffect(() => {
    cargarMascotas();
  }, []);

  const cargarMascotas = () => {
    fetch("http://localhost/mi_proyecto/api/mascotas/leer_mascota.php")
      .then((res) => res.json())
      .then((data) => setMascotas(data));
  };

  const handleChange = (e) => {
    setNuevaMascota({ ...nuevaMascota, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    fetch("http://localhost/mi_proyecto/api/mascotas/crear_mascota.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(nuevaMascota),
    })
      .then((res) => res.json())
      .then((data) => {
        alert(data.mensaje || data.error);
        setNuevaMascota({
          nombre: "",
          tipo: "",
          edad: "",
          raza: "",
          descripcion: "",
          estado: "",
        });
        cargarMascotas();
      });
  };

  const handleEditar = (m) => {
    setEditando(m);
  };

  const handleActualizar = () => {
    fetch("http://localhost/mi_proyecto/api/mascotas/editar_mascota.php", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(editando),
    })
      .then((res) => res.json())
      .then((data) => {
        alert(data.mensaje || data.error);
        setEditando(null);
        cargarMascotas();
      });
  };

  const handleEliminar = (id) => {
    if (!window.confirm("¿Seguro que deseas eliminar esta mascota?")) return;

    fetch("http://localhost/mi_proyecto/api/mascotas/eliminar_mascota.php", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    })
      .then((res) => res.json())
      .then((data) => {
        alert(data.mensaje || data.error);
        cargarMascotas();
      });
  };

  return (
    <div className="App">
      <h1>Gestión de Mascotas 🐾</h1>

      <h2>Agregar Mascota</h2>
      <form onSubmit={handleSubmit}>
        <input name="nombre" placeholder="Nombre" value={nuevaMascota.nombre} onChange={handleChange} />
        <input name="tipo" placeholder="Tipo" value={nuevaMascota.tipo} onChange={handleChange} />
        <input name="edad" placeholder="Edad" value={nuevaMascota.edad} onChange={handleChange} />
        <input name="raza" placeholder="Raza" value={nuevaMascota.raza} onChange={handleChange} />
        <input name="descripcion" placeholder="Descripción" value={nuevaMascota.descripcion} onChange={handleChange} />
        <input name="estado" placeholder="Estado" value={nuevaMascota.estado} onChange={handleChange} />
        <button type="submit">Agregar</button>
      </form>

      {editando && (
        <div>
          <h2>Editar Mascota</h2>
          <input name="nombre" placeholder="Nombre" value={editando.nombre} onChange={(e) => setEditando({ ...editando, nombre: e.target.value })} />
          <input name="tipo" placeholder="Tipo" value={editando.tipo} onChange={(e) => setEditando({ ...editando, tipo: e.target.value })} />
          <input name="edad" placeholder="Edad" value={editando.edad} onChange={(e) => setEditando({ ...editando, edad: e.target.value })} />
          <input name="raza" placeholder="Raza" value={editando.raza} onChange={(e) => setEditando({ ...editando, raza: e.target.value })} />
          <input name="descripcion" placeholder="Descripción" value={editando.descripcion} onChange={(e) => setEditando({ ...editando, descripcion: e.target.value })} />
          <input name="estado" placeholder="Estado" value={editando.estado} onChange={(e) => setEditando({ ...editando, estado: e.target.value })} />
          <button onClick={handleActualizar}>Actualizar</button>
          <button onClick={() => setEditando(null)}>Cancelar</button>
        </div>
      )}

      <h2>Lista de Mascotas</h2>
      <ul>
        {mascotas.map((m) => (
          <li key={m.id}>
            <strong>{m.nombre}</strong> - {m.tipo} ({m.edad} años) - {m.raza}
            <br />
            {m.descripcion} - Estado: {m.estado}
            <br />
            <button onClick={() => handleEditar(m)}>✏️ Editar</button>
            <button onClick={() => handleEliminar(m.id)}>🗑️ Eliminar</button>
            <hr />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;

